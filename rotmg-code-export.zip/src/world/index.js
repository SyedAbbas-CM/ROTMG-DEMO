// src/world/index.js

export { MapManager } from './MapManager.js';
export { getWorldMeta, getSpawnPoint } from './worldRegistry.js';



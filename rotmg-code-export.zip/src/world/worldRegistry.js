// src/world/worldRegistry.js

/**
 * Lightweight world registry utilities that wrap MapManager metadata and
 * provide consistent spawn-point selection for both initial spawns and portal
 * transfers. Keeping this thin avoids widespread imports churn.
 */

/**
 * Fetch world metadata via MapManager.
 * @param {import('./MapManager.js').MapManager} mapManager
 * @param {string} mapId
 * @returns {object} metadata or a minimal default
 */
export function getWorldMeta(mapManager, mapId){
  const meta = mapManager.getMapMetadata(mapId);
  return meta || { mapId, width: 64, height: 64, tileSize: 12, chunkSize: 16 };
}

/**
 * Choose a safe spawn point for a world.
 * Prefers explicit entryPoints, otherwise picks a safe margin position.
 * @param {import('./MapManager.js').MapManager} mapManager
 * @param {string} mapId
 */
export function getSpawnPoint(mapManager, mapId){
  const meta = getWorldMeta(mapManager, mapId);
  // Prefer provided entry points
  if (Array.isArray(meta.entryPoints) && meta.entryPoints.length > 0) {
    const p = meta.entryPoints[0];
    // Avoid spawning directly on a portal tile
    const objects = mapManager.getObjects ? (mapManager.getObjects(mapId) || []) : [];
    const isPortalHere = objects.some(o => o.type === 'portal' && o.x === (p.x ?? 5) && o.y === (p.y ?? 5));
    if (!isPortalHere) return { x: p.x ?? 5, y: p.y ?? 5 };
    const candidates = [
      { dx: 1, dy: 0 }, { dx: -1, dy: 0 }, { dx: 0, dy: 1 }, { dx: 0, dy: -1 },
      { dx: 2, dy: 0 }, { dx: 0, dy: 2 }, { dx: -2, dy: 0 }, { dx: 0, dy: -2 }
    ];
    for (const c of candidates) {
      const sx = (p.x ?? 5) + c.dx;
      const sy = (p.y ?? 5) + c.dy;
      const onPortal = objects.some(o => o.type === 'portal' && o.x === sx && o.y === sy);
      if (!onPortal && !mapManager.isWallOrOutOfBounds?.(sx, sy)) {
        return { x: sx, y: sy };
      }
    }
    return { x: (p.x ?? 5) + 2, y: (p.y ?? 5) };
  }

  // Fallback: pick a location away from edges
  const safeMargin = 5;
  const width  = Math.max(meta.width  || 64, safeMargin * 2 + 2);
  const height = Math.max(meta.height || 64, safeMargin * 2 + 2);
  const x = Math.random() * (width  - safeMargin * 2) + safeMargin;
  const y = Math.random() * (height - safeMargin * 2) + safeMargin;
  return { x, y };
}



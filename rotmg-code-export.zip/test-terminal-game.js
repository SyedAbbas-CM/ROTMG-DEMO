#!/usr/bin/env node

/**
 * Comprehensive test for the terminal overworld game
 * Validates all features work correctly
 */

import { spawn } from 'child_process';
import fs from 'fs';

console.log('🧪 Terminal Overworld Game - Comprehensive Test Suite\n');

// Test 1: File integrity check
console.log('1. 📁 Checking file integrity...');
const requiredFiles = [
    'terminal-overworld.js',
    'play.sh', 
    'COMMANDS.md',
    'src/overworld/OverworldManager.js',
    'src/territorial/TerritorialManager.js',
    'test/overworld/OverworldTestPlayer.js'
];

let allFilesExist = true;
requiredFiles.forEach(file => {
    if (fs.existsSync(file)) {
        console.log(`   ✅ ${file}`);
    } else {
        console.log(`   ❌ ${file} - MISSING!`);
        allFilesExist = false;
    }
});

if (!allFilesExist) {
    console.log('\n❌ Some files are missing! Cannot proceed with tests.');
    process.exit(1);
}

// Test 2: Core system functionality
console.log('\n2. 🔧 Testing core overworld system...');
try {
    const { OverworldManager } = await import('./src/overworld/OverworldManager.js');
    const { TerritorialManager } = await import('./src/territorial/TerritorialManager.js');
    const { OverworldTestPlayer } = await import('./test/overworld/OverworldTestPlayer.js');
    
    console.log('   ✅ All modules import successfully');
    
    // Create instances
    const overworld = new OverworldManager({ seed: 12345 });
    const territorial = new TerritorialManager(overworld);
    const player = new OverworldTestPlayer(overworld, territorial);
    
    console.log('   ✅ All systems initialize successfully');
    
    // Test basic functionality
    const coords = overworld.getHierarchicalCoords(5000, 5000);
    console.log(`   ✅ Coordinate system works: Region (${coords.region.x}, ${coords.region.y})`);
    
    const connections = overworld.getAttackableRegions('5,5');
    console.log(`   ✅ Connection system works: ${connections.length} connections`);
    
    player.teleportToRegion('10,10');
    console.log(`   ✅ Player system works: Moved to ${player.currentRegionId}`);
    
} catch (error) {
    console.log(`   ❌ Core system error: ${error.message}`);
    process.exit(1);
}

// Test 3: Terminal game startup test
console.log('\n3. 🚀 Testing terminal game startup...');

// Create a test script that runs basic commands
const testCommands = [
    'help',
    'info', 
    'debug',
    'zoom 2',
    'w',
    'conn',
    'tp 0 0',
    'stats',
    'quit'
].join('\n');

// Write test commands to a temporary file
fs.writeFileSync('/tmp/test-commands.txt', testCommands);

const testProcess = spawn('node', ['terminal-overworld.js'], {
    stdio: ['pipe', 'pipe', 'pipe']
});

// Send test commands
testProcess.stdin.write(testCommands);
testProcess.stdin.end();

let output = '';
testProcess.stdout.on('data', (data) => {
    output += data.toString();
});

testProcess.stderr.on('data', (data) => {
    console.log(`   ⚠️ stderr: ${data}`);
});

testProcess.on('close', (code) => {
    if (code === 0) {
        console.log('   ✅ Terminal game runs without errors');
        
        // Check for expected output patterns
        const expectedPatterns = [
            'TERMINAL OVERWORLD EXPLORER',
            'Position: Region',
            'COMMANDS',
            'Debug mode',
            'CONTINENTAL VIEW',
            'Region .* connects to'
        ];
        
        let patternChecks = 0;
        expectedPatterns.forEach(pattern => {
            if (new RegExp(pattern).test(output)) {
                patternChecks++;
                console.log(`   ✅ Found expected pattern: ${pattern}`);
            } else {
                console.log(`   ⚠️ Missing pattern: ${pattern}`);
            }
        });
        
        console.log(`   📊 Pattern matching: ${patternChecks}/${expectedPatterns.length} patterns found`);
        
    } else {
        console.log(`   ❌ Terminal game exited with code ${code}`);
    }
    
    // Clean up
    try { fs.unlinkSync('/tmp/test-commands.txt'); } catch {}
    
    // Final summary
    console.log('\n' + '='.repeat(50));
    console.log('🏁 TEST SUMMARY');
    console.log('='.repeat(50));
    console.log('✅ File integrity check: PASSED');
    console.log('✅ Core system functionality: PASSED');
    console.log(`${code === 0 ? '✅' : '❌'} Terminal game execution: ${code === 0 ? 'PASSED' : 'FAILED'}`);
    
    console.log('\n🎮 HOW TO PLAY:');
    console.log('1. Run: ./play.sh');
    console.log('2. Or run: node terminal-overworld.js');
    console.log('3. Use WASD or n/e/s/w to move');
    console.log('4. Type "help" for all commands');
    console.log('5. Try "zoom 1" for mountain view, "zoom 5" for detailed view');
    console.log('6. Use "debug" to see loading information');
    console.log('7. Type "quit" to exit');
    
    console.log('\n📚 Features Available:');
    console.log('• 🕹️  WASD movement controls');
    console.log('• 🔍 Hierarchical zoom (mountain → forest → detailed view)');
    console.log('• 🎲 Procedural variety (no two regions look the same)');
    console.log('• 🐛 Debug mode with loading/memory info');
    console.log('• 🌍 100k x 100k procedural world');
    console.log('• 🗺️  Regional connectivity for strategic movement');
    console.log('• 💾 On-demand loading with memory management');
    
    console.log('\nReady to explore the overworld! 🚀');
});

// Set timeout for test
setTimeout(() => {
    if (!testProcess.killed) {
        testProcess.kill();
        console.log('   ⚠️ Test timed out after 10 seconds');
    }
}, 10000);
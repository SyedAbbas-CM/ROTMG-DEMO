#!/usr/bin/env node

/**
 * Sprite-based Terminal Game
 * Uses actual spritesheet data instead of emojis
 * Much more efficient 5k x 5k world with 100x100 tile chunks
 */

import { EfficientWorldManager } from './src/world/EfficientWorldManager.js';
import readline from 'readline';

// Terminal colors for different terrain types
const colors = {
    reset: '\x1b[0m',
    bright: '\x1b[1m',
    dim: '\x1b[2m',
    
    // Terrain colors
    plains: '\x1b[32m',    // Green
    mountains: '\x1b[37m', // White  
    water: '\x1b[34m',     // Blue
    wasteland: '\x1b[31m', // Red
    forest: '\x1b[32m',    // Green
    desert: '\x1b[33m',    // Yellow
    
    // UI colors
    player: '\x1b[33m\x1b[1m', // Bright Yellow
    info: '\x1b[36m',           // Cyan
    warning: '\x1b[33m',        // Yellow
    error: '\x1b[31m'           // Red
};

class SpriteTerminalGame {
    constructor() {
        this.worldManager = new EfficientWorldManager({
            worldWidth: 5000,
            worldHeight: 5000,
            chunkSize: 100,
            seed: 12345
        });
        
        // Player position (in world coordinates)
        this.playerX = 2500; // Center of world
        this.playerY = 2500;
        
        // View settings
        this.viewRadius = 15; // Show 31x31 tiles around player
        this.showDebug = true;
        this.showChunkBoundaries = false;
        
        this.running = true;
        
        // Setup readline
        this.rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });
        
        console.log(colors.info + colors.bright + '=== SPRITE-BASED WORLD EXPLORER ===' + colors.reset);
        console.log(colors.warning + 'Now using actual spritesheet data from lofiEnvironment.png!' + colors.reset);
        this.printHelp();
    }
    
    async start() {
        this.printStatus();
        this.printMap();
        this.gameLoop();
    }
    
    gameLoop() {
        if (!this.running) {
            this.rl.close();
            return;
        }
        
        this.rl.question(colors.bright + '> ' + colors.reset, (input) => {
            this.processCommand(input.trim().toLowerCase());
            if (this.running) {
                setTimeout(() => this.gameLoop(), 10);
            }
        });
    }
    
    processCommand(command) {
        const parts = command.split(' ');
        const cmd = parts[0];
        
        switch (cmd) {
            case 'help':
            case 'h':
                this.printHelp();
                break;
                
            // Movement (WASD + traditional)
            case 'w':
            case 'north':
            case 'n':
                this.movePlayer(0, -1);
                break;
            case 's':
            case 'south':
                this.movePlayer(0, 1);
                break;
            case 'a':
            case 'west':
                this.movePlayer(-1, 0);
                break;
            case 'd':
            case 'east':
            case 'e':
                this.movePlayer(1, 0);
                break;
                
            case 'move':
            case 'm':
                if (parts.length >= 3) {
                    const dx = parseInt(parts[1]) || 0;
                    const dy = parseInt(parts[2]) || 0;
                    this.movePlayer(dx, dy);
                } else {
                    console.log(colors.error + 'Usage: move <dx> <dy>' + colors.reset);
                }
                break;
                
            case 'jump':
            case 'j':
                if (parts.length >= 3) {
                    const x = parseInt(parts[1]);
                    const y = parseInt(parts[2]);
                    if (!isNaN(x) && !isNaN(y)) {
                        this.jumpTo(x, y);
                    } else {
                        console.log(colors.error + 'Usage: jump <x> <y>' + colors.reset);
                    }
                } else {
                    console.log(colors.error + 'Usage: jump <x> <y>' + colors.reset);
                }
                break;
                
            case 'center':\n                this.jumpTo(2500, 2500); // Jump to world center\n                break;\n                \n            // View commands\n            case 'zoom':\n            case 'z':\n                if (parts.length >= 2) {\n                    const newRadius = parseInt(parts[1]);\n                    if (newRadius >= 5 && newRadius <= 50) {\n                        this.viewRadius = newRadius;\n                        this.printMap();\n                    } else {\n                        console.log(colors.error + 'Zoom must be between 5 and 50' + colors.reset);\n                    }\n                } else {\n                    console.log(colors.error + 'Usage: zoom <radius>' + colors.reset);\n                }\n                break;\n                \n            case 'debug':\n                this.showDebug = !this.showDebug;\n                console.log(colors.warning + `Debug mode: ${this.showDebug ? 'ON' : 'OFF'}` + colors.reset);\n                if (this.showDebug) {\n                    this.printDebugInfo();\n                }\n                break;\n                \n            case 'chunks':\n                this.showChunkBoundaries = !this.showChunkBoundaries;\n                console.log(colors.warning + `Chunk boundaries: ${this.showChunkBoundaries ? 'ON' : 'OFF'}` + colors.reset);\n                this.printMap();\n                break;\n                \n            case 'info':\n            case 'i':\n                this.printDetailedInfo();\n                break;\n                \n            case 'stats':\n                this.printWorldStats();\n                break;\n                \n            case 'clear':\n            case 'cls':\n                console.clear();\n                this.printStatus();\n                this.printMap();\n                break;\n                \n            case 'quit':\n            case 'exit':\n            case 'q':\n                console.log(colors.info + 'Thanks for exploring the sprite-based world!' + colors.reset);\n                this.running = false;\n                this.rl.close();\n                break;\n                \n            default:\n                if (command) {\n                    console.log(colors.error + `Unknown command: ${command}. Type 'help' for commands.` + colors.reset);\n                }\n                break;\n        }\n    }\n    \n    movePlayer(dx, dy) {\n        const newX = Math.max(0, Math.min(this.worldManager.worldWidth - 1, this.playerX + dx));\n        const newY = Math.max(0, Math.min(this.worldManager.worldHeight - 1, this.playerY + dy));\n        \n        if (newX !== this.playerX || newY !== this.playerY) {\n            this.playerX = newX;\n            this.playerY = newY;\n            \n            this.printStatus();\n            this.printMap();\n        } else {\n            console.log(colors.warning + 'Cannot move there - world boundary!' + colors.reset);\n        }\n    }\n    \n    jumpTo(x, y) {\n        const clampedX = Math.max(0, Math.min(this.worldManager.worldWidth - 1, x));\n        const clampedY = Math.max(0, Math.min(this.worldManager.worldHeight - 1, y));\n        \n        this.playerX = clampedX;\n        this.playerY = clampedY;\n        \n        console.log(colors.info + `Jumped to (${this.playerX}, ${this.playerY})` + colors.reset);\n        this.printStatus();\n        this.printMap();\n    }\n    \n    printHelp() {\n        console.log(colors.info + '\\n=== COMMANDS ===' + colors.reset);\n        console.log('Movement:');\n        console.log('  w/a/s/d      - Move with WASD');\n        console.log('  n/e/s/west   - Move with directions');\n        console.log('  move <x> <y> - Move by offset');\n        console.log('  jump <x> <y> - Jump to coordinates');\n        console.log('  center       - Jump to world center');\n        \n        console.log('\\nView:');\n        console.log('  zoom <n>     - Change view radius (5-50)');\n        console.log('  debug        - Toggle debug info');\n        console.log('  chunks       - Show chunk boundaries');\n        console.log('  clear        - Clear screen');\n        \n        console.log('\\nInformation:');\n        console.log('  info         - Detailed position info');\n        console.log('  stats        - World statistics');\n        console.log('  help         - Show this help');\n        \n        console.log('\\nGeneral:');\n        console.log('  quit         - Exit game');\n        \n        console.log(colors.warning + '\\nTERRAIN LEGEND:' + colors.reset);\n        console.log('  . = Plains   ^ = Mountains  ~ = Water');\n        console.log('  T = Forest   s = Desert     x = Wasteland');\n        console.log(`  ${colors.player}@${colors.reset} = You are here`);\n        console.log('');\n    }\n    \n    printStatus() {\n        const chunkCoords = this.worldManager.worldToChunk(this.playerX, this.playerY);\n        \n        console.log(colors.bright + `\\n📍 Position: (${this.playerX}, ${this.playerY})` + colors.reset);\n        console.log(`Chunk: (${chunkCoords.chunkX}, ${chunkCoords.chunkY}) Local: (${chunkCoords.localX}, ${chunkCoords.localY})`);\n        \n        const terrain = this.worldManager.getTerrainAt(this.playerX, this.playerY);\n        console.log(`Terrain: ${terrain.terrainType}`);\n        \n        if (this.showDebug) {\n            const stats = this.worldManager.getStats();\n            console.log(colors.dim + `Loaded chunks: ${stats.loadedChunks}, Memory: ${stats.memoryUsage}` + colors.reset);\n        }\n    }\n    \n    printMap() {\n        console.log(colors.info + `\\n=== WORLD MAP (View Radius: ${this.viewRadius}) ===` + colors.reset);\n        \n        const startTime = Date.now();\n        let chunksLoaded = 0;\n        const initialChunks = this.worldManager.loadedChunks.size;\n        \n        // Print map\n        for (let dy = -this.viewRadius; dy <= this.viewRadius; dy++) {\n            let row = '';\n            for (let dx = -this.viewRadius; dx <= this.viewRadius; dx++) {\n                const worldX = this.playerX + dx;\n                const worldY = this.playerY + dy;\n                \n                if (dx === 0 && dy === 0) {\n                    // Player position\n                    row += colors.player + '@' + colors.reset;\n                } else if (worldX >= 0 && worldX < this.worldManager.worldWidth && \n                          worldY >= 0 && worldY < this.worldManager.worldHeight) {\n                    \n                    const char = this.worldManager.getDisplayChar(worldX, worldY, true);\n                    \n                    // Show chunk boundaries if enabled\n                    if (this.showChunkBoundaries) {\n                        const chunkCoords = this.worldManager.worldToChunk(worldX, worldY);\n                        if (chunkCoords.localX === 0 || chunkCoords.localY === 0) {\n                            row += colors.dim + '|' + colors.reset;\n                        } else {\n                            row += char;\n                        }\n                    } else {\n                        row += char;\n                    }\n                } else {\n                    // Outside world bounds\n                    row += colors.dim + ' ' + colors.reset;\n                }\n            }\n            console.log(row);\n        }\n        \n        chunksLoaded = this.worldManager.loadedChunks.size - initialChunks;\n        const renderTime = Date.now() - startTime;\n        \n        if (this.showDebug && chunksLoaded > 0) {\n            console.log(colors.dim + `[DEBUG] Rendered in ${renderTime}ms, loaded ${chunksLoaded} new chunks` + colors.reset);\n        }\n        console.log('');\n    }\n    \n    printDetailedInfo() {\n        const terrain = this.worldManager.getTerrainAt(this.playerX, this.playerY);\n        const chunkCoords = this.worldManager.worldToChunk(this.playerX, this.playerY);\n        const chunk = this.worldManager.loadChunk(chunkCoords.chunkX, chunkCoords.chunkY);\n        \n        console.log(colors.info + '\\n=== DETAILED INFO ===' + colors.reset);\n        console.log(`World Position: (${this.playerX}, ${this.playerY})`);\n        console.log(`Chunk: (${chunkCoords.chunkX}, ${chunkCoords.chunkY})`);\n        console.log(`Local Position: (${chunkCoords.localX}, ${chunkCoords.localY})`);\n        console.log(`Terrain Type: ${terrain.terrainType}`);\n        console.log(`Sprite: Column ${terrain.sprite.col}, Row ${terrain.sprite.row}`);\n        \n        if (chunk.features && chunk.features.length > 0) {\n            console.log('\\nChunk Features:');\n            chunk.features.forEach((feature, i) => {\n                console.log(`  ${i + 1}. ${feature.type} at (${feature.x}, ${feature.y})`);\n            });\n        }\n        \n        console.log(`\\nChunk Connections: ${chunk.connections.join(', ')}`);\n        console.log('');\n    }\n    \n    printWorldStats() {\n        const stats = this.worldManager.getStats();\n        \n        console.log(colors.info + '\\n=== WORLD STATISTICS ===' + colors.reset);\n        console.log(`World Size: ${stats.worldSize}`);\n        console.log(`Chunk Grid: ${stats.chunkGrid}`);\n        console.log(`Chunk Size: ${stats.chunkSize}`);\n        console.log(`Total Chunks: ${stats.totalChunks}`);\n        console.log(`Loaded Chunks: ${stats.loadedChunks}`);\n        console.log(`Memory Usage: ${stats.memoryUsage}`);\n        \n        const loadPercent = ((stats.loadedChunks / stats.totalChunks) * 100).toFixed(2);\n        console.log(`World Explored: ${loadPercent}%`);\n        console.log('');\n    }\n    \n    printDebugInfo() {\n        const stats = this.worldManager.getStats();\n        console.log(colors.dim + '\\n[DEBUG] System Info:' + colors.reset);\n        console.log(colors.dim + `View radius: ${this.viewRadius}` + colors.reset);\n        console.log(colors.dim + `Loaded chunks: ${stats.loadedChunks}/${stats.totalChunks}` + colors.reset);\n        console.log('');\n    }\n}\n\n// Start the game\nconst game = new SpriteTerminalGame();\ngame.start();
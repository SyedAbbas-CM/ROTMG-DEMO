#!/usr/bin/env node

/**
 * Clean Sprite-based Terminal Game
 * Uses spritesheet data with efficient 5k x 5k world
 */

import { EfficientWorldManager } from './src/world/EfficientWorldManager.js';
import readline from 'readline';

const colors = {
    reset: '\x1b[0m',
    bright: '\x1b[1m',
    player: '\x1b[33m\x1b[1m',
    info: '\x1b[36m',
    warning: '\x1b[33m',
    error: '\x1b[31m'
};

class SpriteGame {
    constructor() {
        this.worldManager = new EfficientWorldManager({
            worldWidth: 5000,
            worldHeight: 5000,
            chunkSize: 100,
            seed: 12345
        });
        
        this.playerX = 2500;
        this.playerY = 2500;
        this.viewRadius = 15;
        this.showDebug = true;
        this.running = true;
        
        this.rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });
        
        console.log(colors.info + '=== SPRITE-BASED WORLD EXPLORER ===' + colors.reset);
        console.log('5k x 5k world with 100x100 tile chunks using spritesheet data');
    }
    
    async start() {
        this.printHelp();
        this.printStatus();
        this.printMap();
        this.gameLoop();
    }
    
    gameLoop() {
        if (!this.running) {
            this.rl.close();
            return;
        }
        
        this.rl.question('> ', (input) => {
            this.processCommand(input.trim().toLowerCase());
            setTimeout(() => this.gameLoop(), 10);
        });
    }
    
    processCommand(command) {
        const parts = command.split(' ');
        
        switch (parts[0]) {
            case 'w': case 'north': this.movePlayer(0, -1); break;
            case 's': case 'south': this.movePlayer(0, 1); break;
            case 'a': case 'west': this.movePlayer(-1, 0); break;
            case 'd': case 'east': this.movePlayer(1, 0); break;
            case 'center': this.jumpTo(2500, 2500); break;
            case 'info': this.printDetailedInfo(); break;
            case 'stats': this.printWorldStats(); break;
            case 'debug': 
                this.showDebug = !this.showDebug;
                console.log(`Debug: ${this.showDebug ? 'ON' : 'OFF'}`);
                break;
            case 'help': this.printHelp(); break;
            case 'quit': case 'q': 
                console.log('Goodbye!');
                this.running = false;
                break;
            default:
                if (command) console.log('Unknown command. Type "help".');
        }
    }
    
    movePlayer(dx, dy) {
        const newX = Math.max(0, Math.min(4999, this.playerX + dx));
        const newY = Math.max(0, Math.min(4999, this.playerY + dy));
        
        if (newX !== this.playerX || newY !== this.playerY) {
            this.playerX = newX;
            this.playerY = newY;
            this.printStatus();
            this.printMap();
        }
    }
    
    jumpTo(x, y) {
        this.playerX = Math.max(0, Math.min(4999, x));
        this.playerY = Math.max(0, Math.min(4999, y));
        console.log(`Jumped to (${this.playerX}, ${this.playerY})`);
        this.printStatus();
        this.printMap();
    }
    
    printHelp() {
        console.log('\n=== COMMANDS ===');
        console.log('w/a/s/d    - Move');
        console.log('center     - Go to world center');
        console.log('info       - Detailed info');
        console.log('stats      - World statistics');
        console.log('debug      - Toggle debug');
        console.log('help       - This help');
        console.log('quit       - Exit');
        console.log('\nLEGEND: . = Plains, ^ = Mountains, ~ = Water');
        console.log('T = Forest, s = Desert, x = Wasteland, @ = You');
        console.log('');
    }
    
    printStatus() {
        const chunkCoords = this.worldManager.worldToChunk(this.playerX, this.playerY);
        const terrain = this.worldManager.getTerrainAt(this.playerX, this.playerY);
        
        console.log(`\nPosition: (${this.playerX}, ${this.playerY})`);
        console.log(`Chunk: (${chunkCoords.chunkX}, ${chunkCoords.chunkY})`);
        console.log(`Terrain: ${terrain.terrainType}`);
        
        if (this.showDebug) {
            const stats = this.worldManager.getStats();
            console.log(`Loaded: ${stats.loadedChunks} chunks, ${stats.memoryUsage}`);
        }
    }
    
    printMap() {
        console.log(`\n=== MAP (Radius: ${this.viewRadius}) ===`);
        
        for (let dy = -this.viewRadius; dy <= this.viewRadius; dy++) {
            let row = '';
            for (let dx = -this.viewRadius; dx <= this.viewRadius; dx++) {
                const worldX = this.playerX + dx;
                const worldY = this.playerY + dy;
                
                if (dx === 0 && dy === 0) {
                    row += '@';
                } else if (worldX >= 0 && worldX < 5000 && worldY >= 0 && worldY < 5000) {
                    row += this.worldManager.getDisplayChar(worldX, worldY, false);
                } else {
                    row += ' ';
                }
            }
            console.log(row);
        }
        console.log('');
    }
    
    printDetailedInfo() {
        const terrain = this.worldManager.getTerrainAt(this.playerX, this.playerY);
        const chunkCoords = this.worldManager.worldToChunk(this.playerX, this.playerY);
        
        console.log('\n=== DETAILED INFO ===');
        console.log(`World Position: (${this.playerX}, ${this.playerY})`);
        console.log(`Chunk: (${chunkCoords.chunkX}, ${chunkCoords.chunkY})`);
        console.log(`Local: (${chunkCoords.localX}, ${chunkCoords.localY})`);
        console.log(`Terrain: ${terrain.terrainType}`);
        console.log(`Sprite: Col ${terrain.sprite.col}, Row ${terrain.sprite.row}`);
        console.log('');
    }
    
    printWorldStats() {
        const stats = this.worldManager.getStats();
        
        console.log('\n=== WORLD STATS ===');
        console.log(`Size: ${stats.worldSize}`);
        console.log(`Chunks: ${stats.chunkGrid} (${stats.totalChunks} total)`);
        console.log(`Loaded: ${stats.loadedChunks}`);
        console.log(`Memory: ${stats.memoryUsage}`);
        console.log(`Explored: ${((stats.loadedChunks / stats.totalChunks) * 100).toFixed(2)}%`);
        console.log('');
    }
}

const game = new SpriteGame();
game.start();